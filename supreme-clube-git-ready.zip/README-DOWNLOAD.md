# Supreme Clube — projeto pronto para Git

Este pacote contém o código-fonte atualizado da landing page. A versão inclui a localização posicionada imediatamente após serviços e não inclui o serviço de troca de vidro.

## Rodar localmente

```bash
pnpm install
pnpm dev
```

Para validar o projeto:

```bash
pnpm check
pnpm build
```

`node_modules`, `dist`, `.git`, logs e arquivos temporários foram excluídos do pacote. Eles não devem ser enviados ao Git.
