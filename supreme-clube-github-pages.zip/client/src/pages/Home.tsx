/*
  * Design direction: Supreme Clube official identity adapted to an urban club aesthetic.
 * Navy blue, white, and electric sky blue mirror the circular brand seal from Instagram.
 * Real Instagram media is used where available; conversion always points to direct WhatsApp
 * and every visit-oriented CTA reminds the visitor to schedule before coming.
 */
import { useState, type ReactNode } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  CalendarDays,
  CarFront,
  Check,
  ChevronDown,
  Clock3,
  Droplets,
  Instagram,
  MapPin,
  Menu,
  MessageCircle,
  MoveRight,
  Quote,
  Scissors,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { MapView } from "@/components/Map";

const WHATSAPP = "https://wa.me/5527992977721";
const BARBER_WHATSAPP = "https://api.whatsapp.com/send?phone=5527998873746&text=Ol%C3%A1%2C%20gostaria%20de%20agendar%20um%20hor%C3%A1rio.";
const INSTAGRAM = "https://www.instagram.com/supremeclube.vv/";
const MAPS =
  "https://www.google.com/maps/search/?api=1&query=Av.%20Saturnino%20Rangel%20Mauro%2C%20405%2C%20Praia%20de%20Itaparica%2C%20Vila%20Velha%2C%20ES";
const waMessage = (message: string) => `${WHATSAPP}?text=${encodeURIComponent(message)}`;

const asset = (name: string) => `${import.meta.env.BASE_URL}assets/${name}`;
const brandLogo = asset("profile-picture.jpg");
const realImages = {
  wash: asset("wash.jpg"),
  finish: asset("finish.jpg"),
  space: asset("space.jpg"),
  barber: asset("barber-real.jpg"),
  videoCover: asset("video-cover.jpg"),
  video: asset("supreme-video.mp4"),
  barberBeard: asset("barber-treated-beard.webp"),
  barberFamily: asset("barber-treated-family.webp"),
  barberAgenda: asset("barber-treated-agenda.webp"),
};

const serviceGroups = [
  {
    number: "01",
    label: "AUTO / ESTÉTICA",
    title: "Lavagem, cuidado e acabamento.",
    description:
      "Uma rotina completa de cuidado para o seu carro, do primeiro contato com a sujeira ao acabamento que devolve presença à pintura.",
    image: realImages.wash,
    icon: CarFront,
    cta: "Agendar estética automotiva",
    message:
      "Olá! Vim pela página do Supreme Clube e quero agendar um serviço de estética automotiva.",
  },
  {
    number: "02",
    label: "PROTEÇÃO / DETAILING",
    title: "Proteção para conservar o que importa.",
    description:
      "Converse com a equipe sobre polimento, vitrificação, PPF e outras soluções para o seu veículo.",
    image: realImages.finish,
    icon: ShieldCheck,
    cta: "Consultar proteção do carro",
    message:
      "Olá! Vim pela página do Supreme Clube e quero consultar polimento, vitrificação, PPF ou proteção.",
  },
];

const serviceDirectory = [
  { name: "Lavagem VIP", note: "Cuidado completo", icon: Sparkles },
  { name: "Lavagem comercial", note: "Rotina automotiva", icon: Droplets },
  { name: "Descontaminação", note: "Preparação da pintura", icon: ShieldCheck },
  { name: "Polimento", note: "Acabamento da pintura", icon: Sparkles },
  { name: "Vitrificação", note: "Proteção e brilho", icon: ShieldCheck },
  { name: "PPF", note: "Proteção de áreas", icon: CarFront },
  { name: "Higienização de bancos e motor", note: "Cuidado interno e técnico", icon: Droplets },
];

const experienceChoices = [
  {
    label: "Estética automotiva",
    title: "Seu carro cuidado.",
    description: "Lavagem VIP, polimento, vitrificação, PPF e higienização para manter presença e acabamento.",
    services: "Lavagem • Polimento • Vitrificação • PPF • Higienização",
    href: "#servicos",
    icon: CarFront,
  },
  {
    label: "Barbearia",
    title: "Você também.",
    description: "Corte, barba e atendimento infantil com técnica, cuidado e acabamento no mesmo endereço.",
    services: "Corte • Barba • Infantil",
    href: "#barbearia",
    icon: Scissors,
  },
];

const comboOptions = [
  { name: "Supreme Combo", detail: "Lavagem + Corte", icon: CarFront },
  { name: "Supreme Duo", detail: "Lavagem + Barba", icon: Scissors },
  { name: "Supreme Experience", detail: "Lavagem + Corte + Barba", icon: Sparkles },
];

const gallery = [
  { src: realImages.wash, alt: "Carro vermelho durante processo de lavagem no Supreme Clube", label: "Lavagem / processo real" },
  { src: realImages.finish, alt: "Produtos de coating e acabamento em bancada do Supreme Clube", label: "Proteção / acabamento" },
  { src: realImages.space, alt: "Interior azul do espaço de estética automotiva Supreme Clube", label: "O espaço / Vila Velha" },
];

const reviews = [
  { quote: "Na Supremecar o carro fica lindo e eu feliz, porque o atendimento é VIP!!!", source: "Comentário público no Instagram" },
  { quote: "O serviço mais top da região!", source: "Comentário público no Instagram" },
  { quote: "Recomendo de olho fechado! Equipe top!!", source: "Comentário público no Instagram" },
  { quote: "Topppp melhor lugar para cuidar dos nossos veículos", source: "Comentário público no Instagram" },
];

const faqs = [
  { question: "Preciso agendar antes de ir?", answer: "Sim. Antes de ir ao Supreme Clube, entre em contato pelo WhatsApp para consultar a disponibilidade e agendar seu atendimento." },
  { question: "Onde fica o Supreme Clube?", answer: "Estamos na Av. Saturnino Rangel Mauro, 405, em Praia de Itaparica, Vila Velha — ES." },
  { question: "Quais serviços automotivos estão disponíveis?", answer: "O clube divulga serviços como lavagem VIP, lavagem comercial, descontaminação, polimento, vitrificação, PPF e higienização de bancos e motor. Confirme a disponibilidade e o escopo com a equipe." },
  { question: "A barbearia também precisa de agendamento?", answer: "Para evitar deslocamento sem atendimento, consulte a equipe pelo WhatsApp antes de ir e confirme a disponibilidade da barbearia." },
  { question: "Posso cuidar do carro e cortar o cabelo no mesmo horário?", answer: "Essa é a proposta do Supreme Clube. Fale com a equipe para confirmar a combinação de serviços e a disponibilidade do horário." },
  { question: "Posso pedir orçamento pelo WhatsApp?", answer: "Sim. Envie uma mensagem com o serviço que deseja consultar e a equipe orientará você sobre escopo e disponibilidade." },
  { question: "A barbearia atende crianças?", answer: "O perfil do Supreme Clube apresenta atendimento infantil. Confirme o horário e os detalhes do corte diretamente com a barbearia." },
  { question: "Quanto tempo dura o atendimento?", answer: "A duração varia conforme o serviço escolhido. Consulte a equipe pelo WhatsApp antes de agendar." },
];

function BrandMark() {
  return <img src={brandLogo} alt="Logo Supreme Clube" className="official-logo" />;
}

function SectionKicker({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return <div className={`section-kicker ${light ? "section-kicker-light" : ""}`}><span className="section-kicker-line" /><span>{children}</span></div>;
}

function ScheduleNotice({ dark = false }: { dark?: boolean }) {
  return <div className={`schedule-notice ${dark ? "schedule-notice-dark" : ""}`}><CalendarDays size={16} /><span><strong>Reserve seu horário e evite espera.</strong> Fale com a equipe antes de ir ao local.</span></div>;
}

type ChatView = "home" | "carro" | "barbearia" | "duvidas" | "localizacao";

function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<ChatView>("home");

  const resetChat = () => setView("home");
  const closeChat = () => { setOpen(false); resetChat(); };

  return <>
    <button className={`chat-launcher ${open ? "chat-launcher-open" : ""}`} type="button" onClick={() => setOpen((current) => !current)} aria-expanded={open} aria-controls="supreme-chat" aria-label={open ? "Fechar assistente do Supreme Clube" : "Abrir assistente do Supreme Clube"} data-umami-event="chat-toggle">
      <MessageCircle size={19} />
    </button>
    {open && <aside className="chat-panel" id="supreme-chat" role="dialog" aria-modal="false" aria-labelledby="chat-title">
      <div className="chat-header"><div><span className="chat-eyebrow">SUPREME CLUBE</span><h2 id="chat-title">Como podemos ajudar?</h2></div><button type="button" className="chat-close" onClick={closeChat} aria-label="Fechar assistente"><X size={17} /></button></div>
      <div className="chat-body">
        {view === "home" && <><p className="chat-intro">Escolha uma opção para encontrar o caminho mais rápido.</p><div className="chat-options"><button type="button" onClick={() => setView("carro")}>Cuidar do meu carro <ArrowUpRight size={15} /></button><button type="button" onClick={() => setView("barbearia")}>Agendar um corte <ArrowUpRight size={15} /></button><button type="button" onClick={() => setView("duvidas")}>Como funciona? <ArrowUpRight size={15} /></button><button type="button" onClick={() => setView("localizacao")}>Ver localização <ArrowUpRight size={15} /></button></div></>}
        {view === "carro" && <ChatAnswer title="Estética automotiva" text="Consulte a equipe sobre lavagem VIP, descontaminação, polimento, vitrificação, PPF e outros cuidados para o seu carro. A disponibilidade é confirmada pelo WhatsApp antes da visita." href={waMessage("Olá! Vim pelo assistente do site e quero consultar um serviço para o meu carro.")} label="Consultar pelo WhatsApp" onBack={resetChat} />}
        {view === "barbearia" && <ChatAnswer title="Barbearia Supreme" text="Para corte ou barba, fale diretamente com a barbearia e combine o melhor horário. Antes de ir ao local, confirme o agendamento pelo WhatsApp." href={BARBER_WHATSAPP} label="Agendar corte" onBack={resetChat} />}
        {view === "duvidas" && <ChatAnswer title="Antes de ir" text="O atendimento é feito com agendamento prévio. Fale com a equipe, confirme o serviço e a disponibilidade e só então vá ao clube." href={waMessage("Olá! Vim pelo assistente do site e tenho uma dúvida sobre o atendimento.")} label="Falar com a equipe" onBack={resetChat} />}
        {view === "localizacao" && <ChatAnswer title="Onde estamos" text="Av. Saturnino Rangel Mauro, 405 — Praia de Itaparica, Vila Velha — ES. Abra a rota e confirme seu horário antes de sair." href={MAPS} label="Abrir rota" onBack={resetChat} external />}
      </div>
      <div className="chat-footer"><span>Sem preços ou disponibilidade automática.</span></div>
    </aside>}
  </>;
}

function ChatAnswer({ title, text, href, label, onBack, external = false }: { title: string; text: string; href: string; label: string; onBack: () => void; external?: boolean }) {
  return <div className="chat-answer"><button type="button" className="chat-back" onClick={onBack}><ArrowDownRight size={14} /> Voltar</button><h3>{title}</h3><p>{text}</p><div className="chat-answer-actions"><a className="chat-action-primary" href={href} target="_blank" rel="noreferrer" data-umami-event="chat-action">{label} <ArrowUpRight size={15} /></a>{!external && <a className="chat-action-secondary" href={MAPS} target="_blank" rel="noreferrer" data-umami-event="chat-map">Ver localização <MapPin size={14} /></a>}</div></div>;
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const closeMenu = () => setMenuOpen(false);

  const geocodeClub = (map: google.maps.Map) => {
    const address = "Av. Saturnino Rangel Mauro, 405, Praia de Itaparica, Vila Velha, ES, Brasil";
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address }, (results, status) => {
      if (status === "OK" && results?.[0]) {
        const location = results[0].geometry.location;
        map.setCenter(location);
        map.setZoom(16);
        new google.maps.marker.AdvancedMarkerElement({ map, position: location, title: "Supreme Clube" });
      }
    });
  };

  return (
    <div className="site-shell">
      <header className="site-header">
        <div className="header-inner">
          <a className="brand-lockup" href="#top" aria-label="Supreme Clube — início"><BrandMark /><span className="brand-wordmark"><strong>SUPREME</strong><span>CLUBE</span></span></a>
          <nav className={`desktop-nav ${menuOpen ? "mobile-nav-open" : ""}`} aria-label="Navegação principal">
            <a href="#experiencia" onClick={closeMenu}>A experiência</a>
            <a href="#servicos" onClick={closeMenu}>Serviços</a>
            <a href="#barbearia" onClick={closeMenu}>Barbearia</a>
            <a href="#como-funciona" onClick={closeMenu}>Como funciona</a>
            <a href="#localizacao" onClick={closeMenu}>Localização</a>
            <a className="nav-mobile-cta" href={waMessage("Olá! Vim pela página do Supreme Clube e quero agendar um atendimento.")} target="_blank" rel="noreferrer" data-umami-event="header-whatsapp">Agendar no WhatsApp <ArrowUpRight size={15} /></a>
          </nav>
          <a className="header-cta" href={waMessage("Olá! Vim pela página do Supreme Clube e quero agendar um atendimento.")} target="_blank" rel="noreferrer" data-umami-event="header-whatsapp">Agendar no WhatsApp <ArrowUpRight size={15} /></a>
          <button className="menu-toggle" aria-label={menuOpen ? "Fechar menu" : "Abrir menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)}>{menuOpen ? <X size={22} /> : <Menu size={22} />}</button>
        </div>
      </header>

      <main id="top">
        <section className="hero-section" aria-labelledby="hero-title">
          <div className="hero-image" role="img" aria-label="Carro vermelho em processo de lavagem no Supreme Clube" />
          <div className="hero-overlay" /><div className="hero-grid" />
          <div className="container hero-content">
            <div className="hero-copy">
              <div className="eyebrow eyebrow-light"><span className="eyebrow-dot" /> BARBEARIA & ESTÉTICA AUTOMOTIVA</div>
              <h1 id="hero-title">Seu carro cuidado.<br /><em>Você também.</em></h1>
              <p>Estética automotiva e barbearia no mesmo lugar. Enquanto seu carro recebe o cuidado que merece, aproveite o tempo para colocar o visual em dia.</p>
              <ScheduleNotice dark />
              <div className="hero-actions">
                <a className="button button-primary" href={waMessage("Olá! Vim pela página do Supreme Clube e quero agendar um serviço de estética automotiva.")} target="_blank" rel="noreferrer" data-umami-event="hero-auto-whatsapp">Agendar estética <MoveRight size={17} /></a>
                <a className="button button-ghost" href={BARBER_WHATSAPP} target="_blank" rel="noreferrer" data-umami-event="hero-barber-whatsapp">Agendar barbearia <Scissors size={16} /></a>
              </div>
            </div>
            <div className="hero-side-note"><MapPin size={16} /><span>Av. Saturnino Rangel Mauro, 405<br />Praia de Itaparica, Vila Velha — ES</span></div>
          </div>
          <div className="hero-footer container"><span>SC / 001</span><span className="hero-footer-rule" /><span>EST. VILA VELHA, ES</span><a href="#servicos" aria-label="Ir para serviços"><ArrowDownRight size={18} /></a></div>
        </section>

<section className="video-feature-section" aria-labelledby="video-title"><div className="container video-feature-layout"><div className="video-copy"><SectionKicker>Visto no Instagram</SectionKicker><h2 id="video-title">O cuidado<br /><em>acontece aqui.</em></h2><p>Veja um pouco do conteúdo real do Supreme Clube e conheça a experiência diretamente no perfil oficial.</p><a className="text-link" href="https://www.instagram.com/p/DH_BT2uxMMt/" target="_blank" rel="noreferrer" data-umami-event="video-instagram">Ver publicação no Instagram <ArrowUpRight size={16} /></a></div><div className="video-preview"><video loop playsInline controls preload="none" poster={realImages.videoCover} aria-label="Vídeo do Supreme Clube mostrando a experiência de estética automotiva, com áudio disponível"><source src={realImages.video} type="video/mp4" /></video><span className="video-shade" /><a className="video-caption" href="https://www.instagram.com/p/DH_BT2uxMMt/" target="_blank" rel="noreferrer" data-umami-event="video-instagram"><span>SUPREME CLUBE / PUBLICAÇÃO REAL</span><ArrowUpRight size={14} /></a></div></div></section>
        <section className="experience-section" id="experiencia" aria-labelledby="experience-title">
          <div className="container experience-layout">
            <div className="experience-number">01<span>/</span>04</div>
            <div className="experience-main"><SectionKicker>O conceito Supreme</SectionKicker><h2 id="experience-title">Uma parada.<br /><span>Dois cuidados.</span></h2><p className="lead-copy">Seu carro recebe atenção. Você também. Uma experiência conveniente e premium para transformar o tempo de espera em um momento de cuidado pessoal.</p><a className="text-link" href={waMessage("Olá! Quero conhecer a experiência completa do Supreme Clube.")} target="_blank" rel="noreferrer" data-umami-event="experience-whatsapp">Quero viver essa experiência <ArrowUpRight size={16} /></a></div>
            <div className="experience-aside"><div className="aside-mark"><BrandMark /></div><p>Uma parada.<br /><strong>Dois cuidados.</strong><br />Mais tempo para você.</p></div>
          </div>
          <div className="container benefit-strip"><div className="benefit-item"><Sparkles size={19} /><span><strong>Cuidado</strong> em cada detalhe</span></div><div className="benefit-item"><Clock3 size={19} /><span><strong>Tempo</strong> melhor aproveitado</span></div><div className="benefit-item"><Check size={19} /><span><strong>Reserva</strong> antes da visita</span></div></div>
        </section>

        <section className="choice-section" aria-labelledby="choice-title"><div className="container"><div className="section-heading-row choice-heading"><div><SectionKicker>Escolha sua experiência</SectionKicker><h2 id="choice-title">Carro ou<br /><em>barbearia?</em></h2></div><p>Dois cuidados, uma mesma parada. Escolha o que você precisa e fale com a equipe para reservar seu horário.</p></div><div className="choice-grid">{experienceChoices.map((choice) => { const Icon = choice.icon; const href = choice.label === "Barbearia" ? BARBER_WHATSAPP : waMessage("Olá! Vim pela página do Supreme Clube e quero agendar um serviço de estética automotiva."); return <article className="choice-card" key={choice.label}><div className="choice-card-top"><span className="choice-icon"><Icon size={22} /></span><span className="choice-label">{choice.label}</span></div><h3>{choice.title}</h3><p>{choice.description}</p><div className="choice-services">{choice.services}</div><a className="button button-dark" href={href} target="_blank" rel="noreferrer" data-umami-event={choice.label === "Barbearia" ? "choice-barber-whatsapp" : "choice-auto-whatsapp"}>{choice.label === "Barbearia" ? "Agendar corte" : "Ver serviços"} <ArrowUpRight size={16} /></a></article>; })}</div></div></section>

        <section className="services-section" id="servicos" aria-labelledby="services-title">
          <div className="container">
            <div className="section-heading-row"><div><SectionKicker light>Serviços do clube</SectionKicker><h2 id="services-title">Cuidado real.<br /><em>Do seu jeito.</em></h2></div><p>Do cuidado diário à proteção avançada, converse com a equipe e encontre o serviço indicado para seu carro.</p></div>
            <ScheduleNotice dark />
            <div className="service-list">{serviceGroups.map((service) => { const Icon = service.icon; return <article className="service-card" key={service.number}><div className="service-image-wrap"><img src={service.image} alt={service.number === "01" ? "Carro vermelho sendo lavado no Supreme Clube" : "Produtos de proteção e acabamento na estrutura do Supreme Clube"} loading="lazy" decoding="async" /><span className="service-index">{service.number}</span></div><div className="service-content"><div className="service-label"><Icon size={15} /> {service.label}</div><h3>{service.title}</h3><p>{service.description}</p><a className="service-link" href={waMessage(service.message)} target="_blank" rel="noreferrer" data-umami-event={`service-${service.number}-whatsapp`}>{service.cta} <ArrowUpRight size={16} /></a></div></article>; })}</div>
            <div className="service-directory"><div className="directory-heading"><SectionKicker light>O que você pode encontrar</SectionKicker><p>Serviços divulgados pelo Supreme Clube. Confirme disponibilidade, escopo e agenda pelo WhatsApp.</p></div><div className="directory-grid">{serviceDirectory.map((service) => { const Icon = service.icon; return <a className="directory-item" key={service.name} href={waMessage(`Olá! Quero consultar a disponibilidade para ${service.name} no Supreme Clube.`)} target="_blank" rel="noreferrer" data-umami-event="directory-whatsapp"><span className="directory-icon"><Icon size={17} /></span><span><strong>{service.name}</strong><small>{service.note}</small></span><ArrowUpRight size={15} /></a>; })}</div></div>
          </div>
        </section>



        <section className="location-section" id="localizacao" aria-labelledby="location-title"><div className="location-map-panel"><MapView className="club-map" initialCenter={{ lat: -20.405, lng: -40.297 }} initialZoom={15} onMapReady={geocodeClub} /><div className="map-overlay-label"><MapPin size={15} /> SUPREME CLUBE / VILA VELHA</div></div><div className="location-content container"><SectionKicker light>Onde encontrar</SectionKicker><h2 id="location-title">Passe no clube<br /><em>em Praia de Itaparica.</em></h2><address><strong>Supreme Clube</strong><br />Av. Saturnino Rangel Mauro, 405<br />Praia de Itaparica, Vila Velha — ES<br />CEP 29102-034, Brasil</address><ScheduleNotice dark /><div className="location-actions"><a className="button button-primary" href={MAPS} target="_blank" rel="noreferrer" data-umami-event="maps-click"><MapPin size={16} /> Abrir rota</a><a className="button button-ghost" href={waMessage("Olá! Quero agendar um atendimento no Supreme Clube. Estou na região de Praia de Itaparica.")} target="_blank" rel="noreferrer" data-umami-event="location-whatsapp"><MessageCircle size={16} /> Agendar no WhatsApp</a></div></div></section>

        <section className="barber-section" id="barbearia" aria-labelledby="barber-title"><div className="container barber-showcase"><div className="barber-copy"><SectionKicker light>Barbearia Supreme</SectionKicker><h2 id="barber-title">Não é mágica.<br /><em>É técnica.</em></h2><p>Barba desenhada, alinhada e pensada para valorizar o seu rosto. Um serviço com tradição, cuidado e acabamento — para adultos e crianças.</p><div className="barber-status"><span>AGENDA</span><strong>ABERTA</strong><small>Marque seu horário antes de ir ao local.</small></div><div className="barber-actions"><a className="button button-primary" href={BARBER_WHATSAPP} target="_blank" rel="noreferrer" data-umami-event="barber-whatsapp">Agendar meu corte <MessageCircle size={16} /></a><a className="button button-ghost" href="https://www.instagram.com/stories/highlights/18081469165952396/" target="_blank" rel="noreferrer" data-umami-event="barber-highlight">Ver destaque <Instagram size={16} /></a></div></div><div className="barber-references" aria-label="Referências da Barbearia Supreme enviadas pelo cliente"><a className="barber-reference barber-reference-main" href="https://www.instagram.com/stories/highlights/18081469165952396/" target="_blank" rel="noreferrer" data-umami-event="barber-highlight"><img src={realImages.barberAgenda} alt="Arte pública do destaque com a agenda da Barbearia Supreme" loading="lazy" decoding="async" /><span>Agenda aberta <ArrowUpRight size={14} /></span></a><div className="barber-reference-stack"><a className="barber-reference" href="https://www.instagram.com/stories/highlights/18081469165952396/" target="_blank" rel="noreferrer" data-umami-event="barber-highlight"><img src={realImages.barberBeard} alt="Antes e depois de barba da Barbearia Supreme" loading="lazy" decoding="async" /><span>Barba desenhada <ArrowUpRight size={14} /></span></a><a className="barber-reference" href="https://www.instagram.com/stories/highlights/18081469165952396/" target="_blank" rel="noreferrer" data-umami-event="barber-highlight"><img src={realImages.barberFamily} alt="Corte de cabelo infantil na Barbearia Supreme" loading="lazy" decoding="async" /><span>De geração em geração <ArrowUpRight size={14} /></span></a></div></div></div></section>

        <section className="combos-section" aria-labelledby="combos-title"><div className="container combos-layout"><div className="combos-intro"><SectionKicker>Uma ideia para o clube</SectionKicker><h2 id="combos-title">Carro +<br /><em>pessoa.</em></h2><p>O diferencial do Supreme pode virar uma experiência combinada. Consulte a equipe sobre a possibilidade de fazer mais de um cuidado na mesma visita.</p><a className="text-link" href={waMessage("Olá! Quero consultar a possibilidade de combinar serviços no Supreme Clube.")} target="_blank" rel="noreferrer" data-umami-event="combos-whatsapp">Consultar combinações <ArrowUpRight size={16} /></a></div><div className="combo-list">{comboOptions.map((combo) => { const Icon = combo.icon; return <a className="combo-item" key={combo.name} href={waMessage(`Olá! Quero consultar a combinação ${combo.name}: ${combo.detail}.`)} target="_blank" rel="noreferrer" data-umami-event="combo-whatsapp"><span className="combo-icon"><Icon size={18} /></span><span><strong>{combo.name}</strong><small>{combo.detail}</small></span><ArrowUpRight size={16} /></a>; })}</div></div></section>

        <section className="instagram-section" aria-labelledby="instagram-title">
          <div className="container instagram-layout"><div className="instagram-intro"><SectionKicker>Conteúdo real</SectionKicker><h2 id="instagram-title">A casa é<br /><em>Supreme.</em></h2><p>Uma seleção de imagens públicas do próprio perfil para mostrar processo, espaço e o cuidado que acontece por aqui.</p><a className="text-link" href={INSTAGRAM} target="_blank" rel="noreferrer" data-umami-event="instagram-gallery">Ver o perfil no Instagram <Instagram size={16} /></a></div><div className="instagram-gallery">{gallery.map((item) => <a className="gallery-card" href={INSTAGRAM} target="_blank" rel="noreferrer" key={item.src} data-umami-event="instagram-gallery"><img src={item.src} alt={item.alt} loading="lazy" decoding="async" /><span>{item.label} <ArrowUpRight size={14} /></span></a>)}</div></div>
        </section>

        <section className="reviews-section" aria-labelledby="reviews-title"><div className="container reviews-heading"><div><SectionKicker>A voz de quem passou por aqui</SectionKicker><h2 id="reviews-title">Quem conhece,<br /><em>recomenda.</em></h2></div><p>Trechos de comentários públicos encontrados no Instagram do Supreme Clube. Para publicar nomes, fotos ou avaliações completas, confirme a autorização com cada cliente.</p></div><div className="container reviews-grid">{reviews.map((review) => <article className="review-card" key={review.quote}><Quote size={22} /><p>“{review.quote}”</p><span>{review.source}</span></article>)}</div><div className="container reviews-cta"><a className="text-link" href={INSTAGRAM} target="_blank" rel="noreferrer" data-umami-event="reviews-instagram">Ver mais no Instagram <ArrowUpRight size={16} /></a></div></section>

        <section className="process-section" id="como-funciona" aria-labelledby="process-title">
          <div className="container process-layout"><div className="process-intro"><SectionKicker>Como funciona</SectionKicker><h2 id="process-title">Antes de sair,<br /><em>fale com a equipe.</em></h2><p>Para garantir que o atendimento ideal esteja disponível, entre em contato e agende sua visita antes de vir ao local.</p><a className="button button-dark" href={waMessage("Olá! Quero agendar minha visita ao Supreme Clube. Pode me orientar sobre a disponibilidade?")} target="_blank" rel="noreferrer" data-umami-event="process-whatsapp">Agendar minha visita <MoveRight size={17} /></a></div><div className="process-steps"><div className="process-step"><span>01</span><div><h3>Você chama</h3><p>Fale com a equipe pelo WhatsApp antes de sair.</p></div></div><div className="process-step"><span>02</span><div><h3>Você agenda</h3><p>Confirme o serviço, a disponibilidade e o melhor horário.</p></div></div><div className="process-step"><span>03</span><div><h3>Você chega</h3><p>Encontre o Supreme Clube em Praia de Itaparica e aproveite a experiência.</p></div></div></div></div>
        </section>

        <section className="manifesto-section" aria-label="Manifesto do Supreme Clube"><div className="container manifesto-inner"><BrandMark /><p>Não é só sobre lavar.<br /><em>É sobre como você sai.</em></p><span className="manifesto-label">SUPREME CLUBE / VILA VELHA</span></div></section>

        <section className="faq-section" aria-labelledby="faq-title"><div className="container faq-layout"><div className="faq-intro"><SectionKicker>Perguntas frequentes</SectionKicker><h2 id="faq-title">Antes de chegar,<br /><em>tire suas dúvidas.</em></h2><p>O primeiro passo é simples: fale com a equipe e agende antes de ir.</p><a className="text-link" href={waMessage("Olá! Tenho uma dúvida e quero agendar um atendimento no Supreme Clube.")} target="_blank" rel="noreferrer" data-umami-event="faq-whatsapp">Falar com a equipe <ArrowUpRight size={16} /></a></div><div className="faq-list">{faqs.map((faq, index) => { const open = activeFaq === index; return <div className={`faq-item ${open ? "faq-item-open" : ""}`} key={faq.question}><button className="faq-question" onClick={() => setActiveFaq(open ? null : index)} aria-expanded={open}><span>{faq.question}</span><ChevronDown size={19} /></button>{open && <p className="faq-answer">{faq.answer}</p>}</div>; })}</div></div></section>


      </main>

      <footer className="site-footer"><div className="container footer-top"><a className="brand-lockup" href="#top" aria-label="Voltar ao início"><BrandMark /><span className="brand-wordmark"><strong>SUPREME</strong><span>CLUBE</span></span></a><p>Estética automotiva + barbearia<br />Praia de Itaparica, Vila Velha — ES</p><a className="footer-phone" href={waMessage("Olá! Quero agendar um atendimento no Supreme Clube.")} target="_blank" rel="noreferrer" data-umami-event="footer-whatsapp"><MessageCircle size={16} /> Agendar pelo WhatsApp <ArrowUpRight size={15} /></a></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} Supreme Clube</span><span>Uma criação <strong>Pulse Ads</strong></span><a href={INSTAGRAM} target="_blank" rel="noreferrer">Instagram <ArrowUpRight size={13} /></a></div></footer>
      <a className="floating-whatsapp" href={waMessage("Olá! Vim pela página do Supreme Clube e quero agendar um atendimento.")} target="_blank" rel="noreferrer" aria-label="Agendar com o Supreme Clube pelo WhatsApp" data-umami-event="floating-whatsapp"><MessageCircle size={22} /><span>Agendar no WhatsApp</span></a>
      <ChatWidget />
    </div>
  );
}
